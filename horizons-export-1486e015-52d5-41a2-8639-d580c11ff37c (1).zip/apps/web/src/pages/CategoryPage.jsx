import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ArrowLeft, ArrowRight, Check } from 'lucide-react';
import Reveal from '@/components/Reveal';
import Header from '@/components/landing/Header';
import Footer from '@/components/landing/Footer';
import { PORTFOLIO, PROFILE, CONTACT } from '@/data/content';

const CategoryPage = () => {
  const { slug } = useParams();
  const category = PORTFOLIO.find((item) => item.slug === slug);

  if (!category) {
    return (
      <div className="bg-background text-foreground antialiased">
        <Header />
        <main className="mx-auto flex min-h-[60vh] max-w-3xl flex-col items-center justify-center px-4 py-32 text-center">
          <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-accent">
            404
          </p>
          <h1 className="mt-4 font-display text-5xl font-medium tracking-tight md:text-6xl">
            Category not found
          </h1>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-muted-foreground">
            That brief doesn’t exist in the studio archive. Head back to the
            portfolio to pick a category.
          </p>
          <Link
            to="/#portfolio"
            className="mt-8 inline-flex items-center gap-2 bg-primary px-7 py-3.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-primary-foreground transition-colors duration-200 hover:bg-accent hover:text-accent-foreground"
          >
            <ArrowLeft className="h-4 w-4" strokeWidth={1.5} />
            Back to Portfolio
          </Link>
        </main>
        <Footer />
      </div>
    );
  }

  const others = PORTFOLIO.filter((item) => item.slug !== category.slug).slice(0, 3);

  return (
    <div className="bg-background text-foreground antialiased">
      <Helmet>
        <title>{category.title} — OB Production | {PROFILE.name}, Mumbai</title>
        <meta
          name="description"
          content={`${category.title} by OB Production — ${PROFILE.name}, Mumbai-based DOP & Photographer. ${category.tagline} Enquire about a ${category.title.toLowerCase()} commission.`}
        />
      </Helmet>
      <Header />
      <main>
        {/* Hero */}
        <section className="bg-background p-3 md:p-5">
          <div className="relative flex min-h-[calc(100dvh-6.5rem)] flex-col overflow-hidden border border-border">
            <div className="relative flex-1 overflow-hidden">
              <img
                src={category.src}
                alt={`${category.title} — OB Production, Mumbai`}
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-primary/35" />
            </div>

            <div className="pointer-events-none absolute inset-0 flex flex-col justify-end">
              <div className="mx-auto w-full max-w-[90rem] px-4 pb-10 md:px-10 md:pb-14">
                <Reveal>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-background/90">
                    {category.exhibit} · {category.tag}
                  </p>
                  <h1 className="mt-4 max-w-4xl font-display text-5xl font-medium leading-[0.95] tracking-tight text-background md:text-8xl">
                    {category.title}
                  </h1>
                  <p className="mt-5 max-w-xl text-sm leading-relaxed text-background/90 md:text-base">
                    {category.tagline}
                  </p>
                </Reveal>
              </div>
            </div>

            <div className="relative flex items-center justify-between border-t border-border px-4 py-3 text-[10px] uppercase tracking-[0.25em] text-muted-foreground md:px-6">
              <Link
                to="/#portfolio"
                className="flex items-center gap-2 transition-colors duration-200 hover:text-accent"
              >
                <ArrowLeft className="h-3.5 w-3.5" strokeWidth={1.5} />
                Portfolio
              </Link>
              <span className="hidden sm:inline">Mumbai — Worldwide</span>
              <a
                href={`mailto:${CONTACT.email}`}
                className="transition-colors duration-200 hover:text-accent"
              >
                Enquire
              </a>
            </div>
          </div>
        </section>

        {/* Overview */}
        <section className="border-b border-border bg-background py-20 md:py-28">
          <div className="mx-auto grid max-w-[90rem] grid-cols-1 gap-12 px-4 md:px-10 lg:grid-cols-12 lg:gap-16">
            <div className="lg:col-span-4">
              <Reveal>
                <p className="flex items-center gap-4 text-[11px] font-semibold uppercase tracking-[0.25em] text-accent">
                  <span className="h-px w-10 bg-accent" aria-hidden="true" />
                  The Brief
                </p>
                <h2 className="mt-6 font-display text-4xl font-medium leading-[1.05] tracking-tight md:text-5xl">
                  {category.descriptor}
                </h2>
              </Reveal>
            </div>
            <div className="lg:col-span-7 lg:col-start-6">
              <Reveal delay={0.1}>
                {category.overview.map((para, i) => (
                  <p
                    key={i}
                    className="text-base leading-relaxed text-muted-foreground md:text-lg [&:not(:first-child)]:mt-5"
                  >
                    {para}
                  </p>
                ))}
              </Reveal>
            </div>
          </div>
        </section>

        {/* Gallery */}
        <section className="border-b border-border bg-secondary py-20 md:py-28">
          <div className="mx-auto max-w-[90rem] px-4 md:px-10">
            <Reveal>
              <div className="flex items-end justify-between gap-6">
                <h2 className="font-display text-4xl font-medium leading-tight tracking-tight md:text-6xl">
                  Selected <span className="text-accent">Frames</span>
                </h2>
                <p className="hidden max-w-xs text-right text-sm leading-relaxed text-muted-foreground md:block">
                  A rotating edit from the {category.title.toLowerCase()} archive.
                </p>
              </div>
            </Reveal>

            <div className="mt-12 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
              {category.gallery.map((src, i) => (
                <Reveal key={i} delay={0.08 * i} y={28}>
                  <div
                    className={`group relative overflow-hidden border border-border ${
                      i % 4 === 0 ? 'aspect-[3/4]' : 'aspect-[4/5]'
                    }`}
                  >
                    <img
                      src={src}
                      alt={`${category.title} frame ${i + 1} — OB Production`}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
                    />
                    <span className="absolute left-3 top-3 bg-background/90 px-2 py-1 text-[10px] font-medium uppercase tracking-[0.2em] text-foreground">
                      Fig. {String(i + 1).padStart(2, '0')}
                    </span>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* Process + Deliverables */}
        <section className="border-b border-border bg-background py-20 md:py-28">
          <div className="mx-auto grid max-w-[90rem] grid-cols-1 gap-16 px-4 md:px-10 lg:grid-cols-2">
            <div>
              <Reveal>
                <p className="flex items-center gap-4 text-[11px] font-semibold uppercase tracking-[0.25em] text-accent">
                  <span className="h-px w-10 bg-accent" aria-hidden="true" />
                  How It Works
                </p>
                <h2 className="mt-6 font-display text-4xl font-medium leading-tight tracking-tight md:text-5xl">
                  From brief to delivery
                </h2>
              </Reveal>
              <div className="mt-10">
                {category.process.map((step, i) => (
                  <Reveal key={step.step} delay={0.08 * i}>
                    <div className="grid grid-cols-[3rem_1fr] gap-4 border-t border-border py-6 last:border-b md:grid-cols-[4rem_1fr]">
                      <span className="font-display text-xl font-medium text-accent">
                        {step.step}
                      </span>
                      <div>
                        <h3 className="font-display text-2xl font-medium tracking-tight">
                          {step.title}
                        </h3>
                        <p className="mt-2 max-w-md text-sm leading-relaxed text-muted-foreground">
                          {step.body}
                        </p>
                      </div>
                    </div>
                  </Reveal>
                ))}
              </div>
            </div>

            <div>
              <Reveal delay={0.1}>
                <p className="flex items-center gap-4 text-[11px] font-semibold uppercase tracking-[0.25em] text-accent">
                  <span className="h-px w-10 bg-accent" aria-hidden="true" />
                  What You Get
                </p>
                <h2 className="mt-6 font-display text-4xl font-medium leading-tight tracking-tight md:text-5xl">
                  Deliverables
                </h2>
                <ul className="mt-10 border-y border-border">
                  {category.deliverables.map((item, i) => (
                    <li
                      key={i}
                      className="flex items-start gap-4 border-b border-border py-5 last:border-b-0"
                    >
                      <span className="mt-0.5 flex h-6 w-6 flex-none items-center justify-center border border-accent text-accent">
                        <Check className="h-3.5 w-3.5" strokeWidth={2} />
                      </span>
                      <span className="text-sm leading-relaxed text-foreground md:text-base">
                        {item}
                      </span>
                    </li>
                  ))}
                </ul>
              </Reveal>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="border-b border-border bg-secondary py-20 text-center md:py-28">
          <div className="mx-auto max-w-3xl px-4 md:px-10">
            <Reveal>
              <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-accent">
                Brief this category
              </p>
              <h2 className="mt-6 font-display text-4xl font-medium leading-tight tracking-tight md:text-6xl">
                Let’s build the {category.tag.toLowerCase()} frame
              </h2>
              <p className="mx-auto mt-5 max-w-md text-sm leading-relaxed text-muted-foreground md:text-base">
                Tell us about the brief, the brand and the moment. We reply to
                every enquiry personally, within two working days.
              </p>
              <div className="mt-9 flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Link
                  to="/#enquiry"
                  className="inline-flex items-center gap-2 bg-primary px-8 py-3.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-primary-foreground transition-colors duration-200 hover:bg-accent hover:text-accent-foreground"
                >
                  Enquire about this brief
                  <ArrowRight className="h-4 w-4" strokeWidth={1.5} />
                </Link>
                <Link
                  to="/#portfolio"
                  className="inline-flex items-center gap-2 border border-border px-8 py-3.5 text-[11px] font-semibold uppercase tracking-[0.22em] transition-colors duration-200 hover:border-accent hover:text-accent"
                >
                  <ArrowLeft className="h-4 w-4" strokeWidth={1.5} />
                  Back to Portfolio
                </Link>
              </div>
            </Reveal>
          </div>
        </section>

        {/* Other categories */}
        <section className="bg-background py-20 md:py-24">
          <div className="mx-auto max-w-[90rem] px-4 md:px-10">
            <Reveal>
              <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-muted-foreground">
                More from the studio
              </p>
            </Reveal>
            <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-3">
              {others.map((item, i) => (
                <Reveal key={item.slug} delay={0.08 * i} y={24}>
                  <Link to={`/category/${item.slug}`} className="group block">
                    <div className="relative aspect-[3/4] overflow-hidden border border-border">
                      <img
                        src={item.src}
                        alt={item.title}
                        loading="lazy"
                        className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
                      />
                      <span className="absolute left-3 top-3 bg-accent px-2 py-1 text-[10px] font-medium uppercase tracking-[0.2em] text-accent-foreground">
                        {item.tag}
                      </span>
                    </div>
                    <div className="mt-4 flex items-center justify-between">
                      <h3 className="font-display text-2xl font-medium tracking-tight">
                        {item.title}
                      </h3>
                      <ArrowRight className="h-4 w-4 text-muted-foreground transition-all duration-200 group-hover:translate-x-1 group-hover:text-accent" strokeWidth={1.5} />
                    </div>
                  </Link>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default CategoryPage;
