import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/landing/Header';
import Hero from '@/components/landing/Hero';
import Studio from '@/components/landing/Studio';
import Portfolio from '@/components/landing/Portfolio';
import Testimonial from '@/components/landing/Testimonial';
import Commissions from '@/components/landing/Commissions';
import CtaBanner from '@/components/landing/CtaBanner';
import Enquiry from '@/components/landing/Enquiry';
import Footer from '@/components/landing/Footer';

const HomePage = () => {
  return (
    <div className="bg-background text-foreground antialiased">
      <Helmet>
        <title>OB Production — Omkar Bhiwapurkar | Photography Portfolio, Mumbai</title>
        <meta
          name="description"
          content="OB Production is the portfolio of Omkar Bhiwapurkar, a Mumbai-based DOP and Photographer defining the visual language of fashion, food and lifestyle. Events, portraits, fashion, e-commerce, food and product photography."
        />
      </Helmet>
      <Header />
      <main>
        <Hero />
        <Studio />
        <Portfolio />
        <Testimonial />
        <Commissions />
        <CtaBanner />
        <Enquiry />
      </main>
      <Footer />
    </div>
  );
};

export default HomePage;
