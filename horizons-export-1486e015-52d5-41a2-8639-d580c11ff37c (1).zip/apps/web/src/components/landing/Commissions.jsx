import React from 'react';
import Reveal from '@/components/Reveal';
import { SERVICES } from '@/data/content';

const Commissions = () => {
  return (
    <section id="commissions" className="border-y border-border bg-secondary py-20 text-foreground md:py-28">
      <div className="mx-auto max-w-[90rem] px-4 md:px-10">
        <Reveal>
          <p className="flex items-center justify-center gap-4 text-[11px] font-semibold uppercase tracking-[0.3em] text-accent">
            <span className="h-px w-10 bg-accent/60" aria-hidden="true" />
            Our Services
            <span className="h-px w-10 bg-accent/60" aria-hidden="true" />
          </p>
          <h2 className="mt-6 text-center font-display text-4xl font-medium leading-tight tracking-tight md:text-6xl">
            A Full-Spectrum Visual Service
          </h2>
        </Reveal>

        <div className="mt-12 border-y border-border">
          {SERVICES.map((item, i) => (
            <Reveal key={item.number} delay={0.08 * i}>
              <div className="grid grid-cols-1 items-center gap-6 border-b border-border py-10 last:border-b-0 md:grid-cols-12 md:py-12">
                <span className="font-display text-2xl font-medium text-accent md:col-span-1">
                  {item.number}
                </span>
                <h3 className="font-display text-3xl font-medium leading-none tracking-tight md:col-span-6 md:text-5xl">
                  {item.title}
                </h3>
                <p className="max-w-sm text-sm leading-relaxed text-muted-foreground md:col-span-3">
                  {item.description}
                </p>
                <div className="hidden md:col-span-2 md:block">
                  <div className="ml-auto aspect-[3/4] w-full max-w-[8.5rem] overflow-hidden border border-border">
                    <img
                      src={item.src}
                      alt={item.title}
                      loading="lazy"
                      className="h-full w-full object-cover"
                    />
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.1}>
          <div className="mt-12 text-center">
            <a
              href="/#enquiry"
              className="inline-block bg-primary px-8 py-3.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-primary-foreground transition-colors duration-200 hover:bg-accent hover:text-accent-foreground"
            >
              Enquire
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default Commissions;
