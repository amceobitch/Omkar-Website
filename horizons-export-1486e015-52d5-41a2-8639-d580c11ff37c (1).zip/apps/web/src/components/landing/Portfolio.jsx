import React from 'react';
import { ArrowRight } from 'lucide-react';
import Reveal from '@/components/Reveal';
import { PORTFOLIO } from '@/data/content';

const Portfolio = () => {
  return (
    <section id="portfolio" className="border-b border-border bg-background py-20 md:py-28">
      <div className="mx-auto max-w-[90rem] px-4 md:px-10">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <Reveal>
            <h2 className="font-display text-5xl font-medium leading-[1.02] tracking-tight md:text-7xl">
              Selected <span className="text-accent">Work</span>
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="max-w-xs text-sm leading-relaxed text-muted-foreground md:text-right">
              A rotating edit across events, portraits, fashion, food and
              product — the full spectrum of the studio.
            </p>
          </Reveal>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-3 lg:gap-6">
          {PORTFOLIO.map((item, i) => (
            <Reveal key={item.title} delay={0.12 * i} y={32}>
              <article className="group">
                <div className="relative aspect-[3/4] overflow-hidden border border-border">
                  <img
                    src={item.src}
                    alt={item.title}
                    loading="lazy"
                    className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
                  />
                  <span className="absolute left-3 top-3 bg-accent px-2 py-1 text-[10px] font-medium uppercase tracking-[0.2em] text-accent-foreground">
                    {item.tag}
                  </span>
                </div>
                <div className="relative z-10 -mt-16 ml-4 mr-4 border-l-2 border-accent border-y border-r border-border bg-background p-5 md:ml-6 md:mr-0 lg:mr-6">
                  <p className="text-[10px] font-medium uppercase tracking-[0.25em] text-accent">
                    {item.exhibit}
                  </p>
                  <h3 className="mt-2 font-display text-2xl font-medium tracking-tight">
                    {item.title}
                  </h3>
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    {item.descriptor}
                  </p>
                  <a
                    href={`/category/${item.slug}`}
                    className="mt-4 inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.2em] underline underline-offset-4 transition-colors duration-200 hover:text-accent"
                  >
                    Brief this category
                    <ArrowRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-1" strokeWidth={1.5} />
                  </a>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
