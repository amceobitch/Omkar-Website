import React from 'react';
import Reveal from '@/components/Reveal';
import { PROFILE } from '@/data/content';

const Testimonial = () => {
  return (
    <section className="border-b border-border bg-secondary py-20 md:py-28">
      <div className="mx-auto max-w-4xl px-4 text-center md:px-10">
        <Reveal>
          <p className="text-[11px] font-semibold uppercase tracking-[0.3em] text-accent">
            The Mandate
          </p>
          <blockquote className="mt-8 font-display text-3xl font-medium leading-snug tracking-tight md:text-5xl md:leading-tight">
            “The go-to creator for brands and individuals who refuse to blend
            into the background.”
          </blockquote>
          <p className="mt-8 text-xs uppercase tracking-[0.25em] text-muted-foreground">
            — {PROFILE.name}, {PROFILE.role}
          </p>
        </Reveal>
      </div>
    </section>
  );
};

export default Testimonial;
