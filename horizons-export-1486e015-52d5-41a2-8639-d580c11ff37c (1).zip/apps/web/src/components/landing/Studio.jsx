import React from 'react';
import Reveal from '@/components/Reveal';
import Exhibit from '@/components/landing/Exhibit';
import { IMAGES, PROFILE, EXPERIENCE, APPROACH } from '@/data/content';

const Studio = () => {
  return (
    <section id="studio" className="border-b border-border bg-background">
      <div className="mx-auto grid max-w-[90rem] grid-cols-1 lg:grid-cols-2">
        {/* Scrolling copy column */}
        <div className="px-4 py-20 md:px-10 md:py-28 lg:pr-16">
          <Reveal>
            <p className="flex items-center gap-4 text-[11px] font-semibold uppercase tracking-[0.25em] text-accent">
              <span className="h-px w-10 bg-accent" aria-hidden="true" />
              My Profile
            </p>
            <h2 className="mt-6 font-display text-5xl font-medium leading-[1.02] tracking-tight md:text-7xl">
              {PROFILE.name}
            </h2>
            <p className="mt-3 text-[11px] font-semibold uppercase tracking-[0.25em] text-muted-foreground">
              {PROFILE.role} · {PROFILE.location}
            </p>
          </Reveal>

          <Reveal delay={0.1}>
            <p className="mt-8 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg">
              {PROFILE.bio}
            </p>
            <p className="mt-5 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg">
              {PROFILE.bio2}
            </p>
          </Reveal>

          <Reveal delay={0.15}>
            <p className="mt-12 text-[10px] font-semibold uppercase tracking-[0.25em] text-muted-foreground">
              My Experiences
            </p>
            <div className="mt-4 grid grid-cols-1 divide-y divide-border border-y border-border sm:grid-cols-3 sm:divide-y-0 sm:divide-x">
              {EXPERIENCE.map((exp) => (
                <div key={exp.label} className="px-4 py-6 first:pl-0 sm:px-6">
                  <p className="font-display text-4xl font-semibold tracking-tight md:text-5xl">
                    {exp.year}
                  </p>
                  <p className="mt-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                    {exp.label}
                  </p>
                </div>
              ))}
            </div>
          </Reveal>

          <div className="mt-12">
            {APPROACH.map((principle, i) => (
              <Reveal key={principle.number} delay={0.08 * i}>
                <div className="grid grid-cols-[3rem_1fr] gap-4 border-t border-border py-6 last:border-b md:grid-cols-[4rem_1fr]">
                  <span className="font-display text-xl font-medium text-accent">
                    {principle.number}
                  </span>
                  <div>
                    <h3 className="font-display text-2xl font-medium tracking-tight">
                      {principle.title}
                    </h3>
                    <p className="mt-2 max-w-md text-sm leading-relaxed text-muted-foreground">
                      {principle.body}
                    </p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>

        {/* Sticky visual anchor */}
        <div className="relative border-t border-border lg:border-l lg:border-t-0">
          <div className="sticky top-16 px-4 py-16 md:px-10 lg:py-28">
            <Reveal y={32}>
              <Exhibit
                src={IMAGES.studioPortrait}
                alt="Rembrandt-lit portrait study from the Mumbai studio"
                label="Fig. 01"
                caption="Portrait · 85mm · Mumbai studio"
                ratio="aspect-[3/4]"
                className="mx-auto max-w-md"
              />
            </Reveal>
            <Reveal delay={0.15}>
              <p className="mx-auto mt-8 max-w-md border-l-2 border-accent pl-4 text-sm italic leading-relaxed text-muted-foreground">
                “From the electric energy of live events to the polished
                precision of a commercial studio — a full-spectrum visual
                service.”
              </p>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Studio;
