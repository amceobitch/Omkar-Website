import React from 'react';
import Reveal from '@/components/Reveal';
import { IMAGES } from '@/data/content';

const CtaBanner = () => {
  return (
    <section className="relative overflow-hidden">
      <div className="grid h-[75vh] min-h-[32rem] grid-cols-2">
        <div className="relative overflow-hidden">
          <img
            src={IMAGES.ctaLeft}
            alt="Editorial portrait of a man in a raw denim jacket"
            loading="lazy"
            className="h-full w-full object-cover"
          />
        </div>
        <div className="relative overflow-hidden border-l border-white/15">
          <img
            src={IMAGES.ctaRight}
            alt="Profile portrait with dramatic window-blind shadows"
            loading="lazy"
            className="h-full w-full object-cover"
          />
        </div>
      </div>
      <div className="absolute inset-0 bg-primary/45" />
      <div className="absolute inset-0 flex items-center justify-center px-6">
        <Reveal>
          <div className="max-w-xl text-center">
            <h2 className="font-display text-5xl font-medium leading-[1.02] tracking-tight text-background md:text-7xl">
              Let’s Collaborate
            </h2>
            <p className="mx-auto mt-6 max-w-md text-sm leading-relaxed text-background/85 md:text-base">
              From the electric energy of live events to the polished precision
              of a commercial studio — let’s create imagery that elevates your
              brand.
            </p>
            <a
              href="/#enquiry"
              className="mt-8 inline-block bg-background px-8 py-3.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-foreground transition-colors duration-200 hover:bg-accent hover:text-accent-foreground"
            >
              Start a Project
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default CtaBanner;
