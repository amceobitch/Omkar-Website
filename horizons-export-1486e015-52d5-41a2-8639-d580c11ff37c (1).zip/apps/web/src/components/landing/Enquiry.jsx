import React, { useState } from 'react';
import { CheckCircle2, Loader2 } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import Reveal from '@/components/Reveal';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { CONTACT, SOCIALS } from '@/data/content';

const SESSION_TYPES = [
  { value: 'event', label: 'Event Photography' },
  { value: 'portrait', label: 'Portrait Photography' },
  { value: 'fashion', label: 'Fashion Photography' },
  { value: 'ecommerce', label: 'E-Commerce / Commercials' },
  { value: 'food', label: 'Food Photography' },
  { value: 'product', label: 'Product Photography' },
  { value: 'other', label: 'Something Else' },
];

const initialForm = { name: '', email: '', sessionType: '', message: '' };

const inputClass =
  'w-full border border-border bg-transparent px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 transition-colors duration-200 focus:border-accent focus:outline-none';

const labelClass =
  'mb-2 block text-[10px] font-semibold uppercase tracking-[0.25em] text-muted-foreground';

const Enquiry = () => {
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState('idle'); // idle | submitting | success | error
  const [error, setError] = useState('');

  const update = (field) => (event) =>
    setForm((prev) => ({ ...prev, [field]: event.target.value }));

  const handleSubmit = async (event) => {
    event.preventDefault();
    setStatus('submitting');
    setError('');
    try {
      await pb.collection('enquiries').create({
        name: form.name.trim(),
        email: form.email.trim(),
        sessionType: form.sessionType || 'other',
        message: form.message.trim(),
      });
      setStatus('success');
      setForm(initialForm);
    } catch (err) {
      console.error('Enquiry submission failed', err);
      setError(
        'Something went wrong while sending your enquiry. Please try again, or write to us directly at hello@reallygreatsite.com.',
      );
      setStatus('error');
    }
  };

  return (
    <section id="enquiry" className="border-b border-border bg-background py-20 md:py-28">
      <div className="mx-auto grid max-w-[90rem] grid-cols-1 gap-16 px-4 md:px-10 lg:grid-cols-2">
        {/* Contact details */}
        <Reveal>
          <div>
            <p className="flex items-center gap-4 text-[11px] font-semibold uppercase tracking-[0.25em] text-accent">
              <span className="h-px w-10 bg-accent" aria-hidden="true" />
              Connect
            </p>
            <h2 className="mt-6 font-display text-5xl font-medium leading-[1.02] tracking-tight md:text-6xl">
              Let’s Collaborate
            </h2>
            <p className="mt-6 max-w-md text-base leading-relaxed text-muted-foreground">
              Tell us about the brief, the brand and the moment you want
              captured. We reply to every enquiry personally, within two
              working days.
            </p>

            <dl className="mt-10 max-w-md divide-y divide-border border-y border-border">
              {[
                ['Email', CONTACT.email, `mailto:${CONTACT.email}`],
                ['Telephone', CONTACT.phone, `tel:${CONTACT.phone.replace(/\s/g, '')}`],
                ['Studio', CONTACT.address, null],
                ['Hours', CONTACT.hours, null],
              ].map(([term, value, href]) => (
                <div key={term} className="grid grid-cols-[7rem_1fr] gap-4 py-4">
                  <dt className="text-[10px] font-semibold uppercase tracking-[0.25em] text-muted-foreground">
                    {term}
                  </dt>
                  <dd className="text-sm">
                    {href ? (
                      <a
                        href={href}
                        className="underline underline-offset-4 transition-colors duration-200 hover:text-accent"
                      >
                        {value}
                      </a>
                    ) : (
                      value
                    )}
                  </dd>
                </div>
              ))}
            </dl>

            <div className="mt-8 flex gap-6">
              {SOCIALS.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noreferrer"
                  className="text-[11px] font-semibold uppercase tracking-[0.2em] underline underline-offset-4 transition-colors duration-200 hover:text-accent"
                >
                  {social.label}
                </a>
              ))}
            </div>
          </div>
        </Reveal>

        {/* Enquiry form */}
        <Reveal delay={0.1}>
          <div className="border border-border bg-secondary/50 p-6 md:p-10">
            {status === 'success' ? (
              <div className="flex min-h-[24rem] flex-col items-center justify-center text-center">
                <CheckCircle2 className="h-10 w-10 text-accent" strokeWidth={1.5} />
                <h3 className="mt-6 font-display text-3xl font-medium tracking-tight">
                  Your enquiry is with the studio
                </h3>
                <p className="mt-3 max-w-sm text-sm leading-relaxed text-muted-foreground">
                  Thank you for writing. We read every brief personally and
                  will reply within two working days.
                </p>
                <button
                  type="button"
                  onClick={() => setStatus('idle')}
                  className="mt-8 border border-border px-6 py-3 text-[11px] font-semibold uppercase tracking-[0.22em] transition-colors duration-200 hover:border-accent hover:text-accent"
                >
                  Send another enquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} noValidate={false}>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div>
                    <label htmlFor="enquiry-name" className={labelClass}>
                      Name
                    </label>
                    <input
                      id="enquiry-name"
                      type="text"
                      required
                      maxLength={120}
                      value={form.name}
                      onChange={update('name')}
                      placeholder="Your full name"
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <label htmlFor="enquiry-email" className={labelClass}>
                      Email
                    </label>
                    <input
                      id="enquiry-email"
                      type="email"
                      required
                      value={form.email}
                      onChange={update('email')}
                      placeholder="you@example.com"
                      className={inputClass}
                    />
                  </div>
                </div>

                <div className="mt-6">
                  <label htmlFor="enquiry-type" className={labelClass}>
                    Session type
                  </label>
                  <Select
                    value={form.sessionType}
                    onValueChange={(value) =>
                      setForm((prev) => ({ ...prev, sessionType: value }))
                    }
                  >
                    <SelectTrigger
                      id="enquiry-type"
                      className="w-full rounded-none border-border bg-transparent px-4 py-3 text-sm focus:ring-0 focus:ring-offset-0"
                    >
                      <SelectValue placeholder="Choose a commission" />
                    </SelectTrigger>
                    <SelectContent className="rounded-none border-border bg-popover">
                      {SESSION_TYPES.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="mt-6">
                  <label htmlFor="enquiry-message" className={labelClass}>
                    Your story
                  </label>
                  <textarea
                    id="enquiry-message"
                    required
                    maxLength={2000}
                    rows={5}
                    value={form.message}
                    onChange={update('message')}
                    placeholder="The occasion, the people, the place — and when it happens."
                    className={`${inputClass} resize-none`}
                  />
                </div>

                {status === 'error' && (
                  <p className="mt-4 border border-destructive/40 bg-destructive/10 px-4 py-3 text-xs leading-relaxed text-destructive">
                    {error}
                  </p>
                )}

                <button
                  type="submit"
                  disabled={status === 'submitting'}
                  className="mt-8 flex w-full items-center justify-center gap-3 bg-primary px-8 py-4 text-[11px] font-semibold uppercase tracking-[0.25em] text-primary-foreground transition-all duration-200 hover:bg-accent hover:text-accent-foreground active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {status === 'submitting' && (
                    <Loader2 className="h-4 w-4 animate-spin" strokeWidth={1.5} />
                  )}
                  {status === 'submitting' ? 'Sending' : 'Send Enquiry'}
                </button>
              </form>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default Enquiry;
