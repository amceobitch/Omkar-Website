import React from 'react';
import { CONTACT, NAV_LINKS, SOCIALS } from '@/data/content';

const Footer = () => {
  return (
    <footer className="overflow-hidden bg-background">
      <div className="mx-auto max-w-[90rem] px-4 pt-16 md:px-10 md:pt-20">
        <div className="grid grid-cols-2 gap-10 border-t border-border pt-12 md:grid-cols-4">
          <div className="col-span-2 md:col-span-1">
            <p className="font-display text-2xl font-medium tracking-tight">
              OB Production<span className="text-accent">.</span>
            </p>
            <p className="mt-3 max-w-[16rem] text-sm leading-relaxed text-muted-foreground">
              Photographs that outlive the hour.
            </p>
          </div>

          <nav aria-label="Footer">
            <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-muted-foreground">
              Sitemap
            </p>
            <ul className="mt-4 space-y-2">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm transition-colors duration-200 hover:text-accent"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-muted-foreground">
              Contact
            </p>
            <ul className="mt-4 space-y-2 text-sm">
              <li>
                <a
                  href={`mailto:${CONTACT.email}`}
                  className="transition-colors duration-200 hover:text-accent"
                >
                  {CONTACT.email}
                </a>
              </li>
              <li>{CONTACT.phone}</li>
              <li>{CONTACT.address}</li>
            </ul>
          </div>

          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.25em] text-muted-foreground">
              Social
            </p>
            <ul className="mt-4 space-y-2">
              {SOCIALS.map((social) => (
                <li key={social.label}>
                  <a
                    href={social.href}
                    target="_blank"
                    rel="noreferrer"
                    className="text-sm transition-colors duration-200 hover:text-accent"
                  >
                    {social.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-start justify-between gap-2 border-t border-border py-5 text-[10px] uppercase tracking-[0.2em] text-muted-foreground sm:flex-row sm:items-center">
          <span>© 2026 OB Production</span>
          <span>Mumbai — Worldwide</span>
        </div>
      </div>

      {/* Cropped display word — brand device */}
      <div className="overflow-hidden" aria-hidden="true">
        <p className="-mb-[0.22em] whitespace-nowrap text-center font-display text-[23vw] font-semibold leading-[0.8] tracking-tight text-primary">
          OB PRODUCTION
        </p>
      </div>
    </footer>
  );
};

export default Footer;
