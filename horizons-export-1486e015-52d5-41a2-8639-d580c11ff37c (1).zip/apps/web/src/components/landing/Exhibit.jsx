import React from 'react';
import { cn } from '@/lib/utils';

const CornerMark = ({ className }) => (
  <span
    aria-hidden="true"
    className={cn(
      'pointer-events-none absolute z-10 select-none text-sm font-light leading-none text-accent',
      className,
    )}
  >
    +
  </span>
);

/**
 * Annotated exhibit frame — hairline border, reference marks at the
 * corners, and a catalogue-style caption row beneath the image.
 */
const Exhibit = ({ src, alt, label, caption, ratio = 'aspect-[3/4]', className, imgClassName }) => (
  <figure className={cn('relative', className)}>
    <CornerMark className="-left-2 -top-2" />
    <CornerMark className="-right-2 -top-2" />
    <CornerMark className="-bottom-2 -left-2" />
    <CornerMark className="-bottom-2 -right-2" />
    <div className="border border-border bg-background p-2">
      <div className={cn('overflow-hidden', ratio)}>
        <img
          src={src}
          alt={alt}
          loading="lazy"
          className={cn('h-full w-full object-cover', imgClassName)}
        />
      </div>
      {(label || caption) && (
        <figcaption className="flex items-baseline justify-between gap-4 px-1 pb-1 pt-3">
          {label && (
            <span className="shrink-0 text-[10px] font-medium uppercase tracking-[0.25em] text-accent">
              {label}
            </span>
          )}
          {caption && (
            <span className="text-right text-[10px] uppercase tracking-[0.15em] text-muted-foreground">
              {caption}
            </span>
          )}
        </figcaption>
      )}
    </div>
  </figure>
);

export default Exhibit;
