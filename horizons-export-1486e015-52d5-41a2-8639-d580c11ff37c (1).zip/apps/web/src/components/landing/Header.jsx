import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { NAV_LINKS } from '@/data/content';
const Header = () => {
  const [open, setOpen] = useState(false);
  return <>
      <header className="sticky top-0 z-50 border-b-2 border-accent bg-background text-foreground">
        <div className="mx-auto flex h-16 max-w-[90rem] items-center justify-between px-4 md:px-8">
          <a href="/#home" className="font-display text-2xl font-medium tracking-tight" aria-label="OB Production — back to top">OB PRODUCTIONS<span className="text-accent">.</span></a>

          <nav className="hidden items-center gap-8 md:flex" aria-label="Primary">
            {NAV_LINKS.map(link => <a key={link.href} href={link.href} className="text-[11px] font-medium uppercase tracking-[0.22em] text-foreground/70 transition-colors duration-200 hover:text-accent">
                {link.label}
              </a>)}
          </nav>

          <div className="flex items-center gap-3">
            <a href="/#enquiry" className="hidden bg-accent px-5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-accent-foreground transition-colors duration-200 hover:bg-primary hover:text-primary-foreground md:inline-block">
              Inquire
            </a>
            <button type="button" onClick={() => setOpen(true)} className="flex h-11 w-11 items-center justify-center md:hidden" aria-label="Open menu">
              <Menu className="h-5 w-5" strokeWidth={1.5} />
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {open && <motion.div initial={{
        opacity: 0
      }} animate={{
        opacity: 1
      }} exit={{
        opacity: 0
      }} transition={{
        duration: 0.2
      }} className="fixed inset-0 z-[60] flex flex-col bg-background text-foreground md:hidden">
            <div className="flex h-16 items-center justify-between border-b border-border px-4">
              <span className="font-display text-2xl font-medium tracking-tight">
                OB Production<span className="text-accent">.</span>
              </span>
              <button type="button" onClick={() => setOpen(false)} className="flex h-11 w-11 items-center justify-center" aria-label="Close menu">
                <X className="h-5 w-5" strokeWidth={1.5} />
              </button>
            </div>
            <nav className="flex flex-1 flex-col justify-center gap-2 px-6" aria-label="Mobile">
              {NAV_LINKS.map((link, i) => <motion.a key={link.href} href={link.href} onClick={() => setOpen(false)} initial={{
            opacity: 0,
            y: 16
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.08 + i * 0.06,
            duration: 0.3,
            ease: 'easeOut'
          }} className="border-b border-border py-4 font-display text-4xl font-medium">
                  {link.label}
                </motion.a>)}
              <motion.a href="/#enquiry" onClick={() => setOpen(false)} initial={{
            opacity: 0,
            y: 16
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.36,
            duration: 0.3,
            ease: 'easeOut'
          }} className="mt-8 bg-accent px-6 py-4 text-center text-xs font-semibold uppercase tracking-[0.22em] text-accent-foreground">
                Inquire
              </motion.a>
            </nav>
          </motion.div>}
      </AnimatePresence>
    </>;
};
export default Header;