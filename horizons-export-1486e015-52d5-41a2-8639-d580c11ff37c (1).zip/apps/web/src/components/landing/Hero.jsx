import React from 'react';
import { motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';
import { IMAGES } from '@/data/content';

const Hero = () => {
  return (
    <section id="home" className="bg-background p-3 md:p-5">
      <div className="relative flex min-h-[calc(100dvh-6.5rem)] flex-col overflow-hidden border border-border">
        {/* Dual image stage (background) */}
        <div className="grid flex-1 grid-cols-1 md:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.1, ease: 'easeOut' }}
            className="relative h-[42vh] overflow-hidden md:h-auto"
          >
            <img
              src={IMAGES.heroLeft}
              alt="Studio portrait — fashion and lifestyle, Mumbai"
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-primary/25" />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.1, delay: 0.15, ease: 'easeOut' }}
            className="relative h-[42vh] overflow-hidden border-t border-border md:h-auto md:border-l md:border-t-0"
          >
            <img
              src={IMAGES.heroRight}
              alt="Editorial fashion portrait on a foggy rooftop at dawn"
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-primary/25" />
          </motion.div>
        </div>

        {/* Overlapping center content layer */}
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center p-4">
          <motion.div
            initial={{ y: 20, opacity: 0, scale: 0.95 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            transition={{ duration: 0.9, delay: 0.35, ease: 'easeOut' }}
            className="relative h-64 w-48 overflow-hidden border-2 border-background/25 shadow-2xl md:h-80 md:w-64 bg-muted"
          >
            <img
              src="https://obedient-lion.staticdomains.app/FC8FB01C-3C65-426B-89FB-43A656B9DAD2.PNG"
              alt="Featured editorial shot"
              className="h-full w-full object-cover"
              onError={(e) => {
                console.error("Image failed to load:", e);
              }}
            />
            <div className="absolute inset-0 bg-primary/10" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8, ease: 'easeOut' }}
            className="mt-6 flex flex-col items-center gap-5 px-6 text-center"
          >
            <p className="max-w-md text-sm leading-relaxed text-background/90 md:text-base drop-shadow-md">
              Mumbai-based DOP & Photographer defining the visual language of
              fashion, food and lifestyle — striking portraits and
              high-conversion imagery for brands that refuse to blend in.
            </p>
            <a
              href="/#portfolio"
              className="bg-background px-7 py-3 text-[11px] font-semibold uppercase tracking-[0.22em] text-foreground shadow-lg transition-colors duration-200 hover:bg-accent hover:text-accent-foreground"
            >
              View Work
            </a>
          </motion.div>
        </div>

        {/* Reference strip along the bottom of the frame */}
        <div className="relative z-20 flex items-center justify-between border-t border-border px-4 py-3 text-[10px] uppercase tracking-[0.25em] text-muted-foreground md:px-6 bg-background/50 backdrop-blur-sm">
          <span>N°01 — Portfolio</span>
          <a
            href="/#studio"
            className="flex items-center gap-2 transition-colors duration-200 hover:text-accent"
            aria-label="Scroll to the studio section"
          >
            Scroll
            <ArrowDown className="h-3.5 w-3.5 animate-bounce" strokeWidth={1.5} />
          </a>
          <span className="hidden sm:inline">Mumbai — Worldwide</span>
        </div>
      </div>
    </section>
  );
};

export default Hero;