export const PROFILE = {
  name: 'Omkar Bhiwapurkar',
  role: 'DOP & Photographer',
  location: 'Mumbai, India',
  bio: 'Omkar Bhiwapurkar is a Mumbai-based DOP and Photographer defining the visual language of fashion, food, and lifestyle. Blending technical mastery with an eye for contemporary trends, he creates striking portraits and high-conversion imagery that elevates every subject.',
  bio2:
    'From the electric energy of live events to the polished precision of a commercial studio, Omkar provides a full-spectrum visual service. He is the go-to creator for brands and individuals who refuse to blend into the background.',
};

export const EXPERIENCE = [
  { year: '2016', label: 'Photography' },
  { year: '2017', label: 'Cinematography' },
  { year: '2021', label: 'Aerial Photography' },
];

export const APPROACH = [
  {
    number: '01',
    title: 'Full-spectrum service',
    body: 'From the electric energy of live events to the polished precision of a commercial studio — one creator, every format.',
  },
  {
    number: '02',
    title: 'Technical mastery, contemporary eye',
    body: 'Blending technical mastery with an eye for contemporary trends to create striking portraits and high-conversion imagery.',
  },
  {
    number: '03',
    title: 'Built to stand out',
    body: 'The go-to creator for brands and individuals who refuse to blend into the background.',
  },
];

export const IMAGES = {
  heroLeft:
    'https://horizons-cdn.hostinger.com/1486e015-52d5-41a2-8639-d580c11ff37c/020a7811-7IAyD.JPG',
  heroRight:
    'https://horizons-cdn.hostinger.com/1486e015-52d5-41a2-8639-d580c11ff37c/img_4107-b6qI9.jpg',
  studioPortrait:
    'https://horizons-cdn.hostinger.com/1486e015-52d5-41a2-8639-d580c11ff37c/487aa70f8c155437d444a8da51d3e97f.jpg',
  ctaLeft:
    'https://images.hostinger.com/8cd366a2-8830-44f9-b032-683b53628be6.png',
  ctaRight:
    'https://images.hostinger.com/9d72cd6e-883d-4bfe-a39f-8929e25b1d00.png',
  food:
    'https://horizons-cdn.hostinger.com/1486e015-52d5-41a2-8639-d580c11ff37c/107dca19f999658fbc36778d9793cbb3.jpg',
  product:
    'https://images.hostinger.com/8f637967-5508-4024-9f76-572ebe2ce6b0.png',
};

export const PORTFOLIO = [
  {
    slug: 'event',
    src: 'https://iili.io/n7EqTlV.jpg',
    exhibit: 'EXH. 01',
    title: 'Wedding Photography',
    descriptor: 'Timeless Moments . Endless Memories .',
    tag: 'Wedding',
    tagline: 'Timeless Moments . Endless Memories .',
    overview: [
      'From the electric energy of live events to candid, in-the-moment frames — OB Production documents the atmosphere as it unfolds. Weddings, brand launches, corporate gatherings, concerts and private celebrations are covered end-to-end with a documentary eye and a polished finish.',
      'Every event is approached with a run-sheet in one hand and an instinct for the unplanned moment in the other. The result is a complete visual record: the grand gestures and the quiet in-between frames that never make the programme.',
    ],
    gallery: [
      'https://freeimage.host/i/n7EqTlV',
      'https://images.hostinger.com/98f1fb85-3be6-4419-a4c3-805788d4c44c.png',
      IMAGES.heroLeft,
      IMAGES.ctaLeft,
    ],
    deliverables: [
      'Full-day or multi-day live coverage',
      'Candid, documentary and posed frames',
      'Edited online gallery within 7 working days',
      'Print-ready high-resolution downloads',
    ],
    process: [
      { step: '01', title: 'Brief & run-sheet', body: 'We map the schedule, key moments and must-have frames before the day begins.' },
      { step: '02', title: 'Live coverage', body: 'Two angles, fast glass and an instinct for the unplanned moment — nothing staged, nothing missed.' },
      { step: '03', title: 'Edit & deliver', body: 'A curated, colour-graded gallery delivered online and print-ready within seven working days.' },
    ],
  },
  {
    slug: 'portrait',
    src: 'https://horizons-cdn.hostinger.com/1486e015-52d5-41a2-8639-d580c11ff37c/408b1dbd63b2bba4d9bfd337261577f2.jpg',
    exhibit: 'EXH. 02',
    title: 'Commercial Photography',
    descriptor: 'Striking portraits that elevate every subject',
    tag: 'Commercial',
    tagline: 'Rembrandt-lit studies that elevate every subject.',
    overview: [
      'Striking portraits that elevate every subject. Whether it is a personal brand, a corporate headshot series or a fine-art character study, each portrait is sculpted with deliberate light and a direction that brings out the person behind the face.',
      'Sessions are paced around the subject — time to settle, time to play, time to find the frame that feels like them. The studio works in both controlled Mumbai sets and on-location environments.',
    ],
    gallery: [
      'https://horizons-cdn.hostinger.com/1486e015-52d5-41a2-8639-d580c11ff37c/408b1dbd63b2bba4d9bfd337261577f2.jpg',
      IMAGES.studioPortrait,
      'https://images.hostinger.com/7538c911-f29a-40d9-a38b-c474d1619a69.png',
      IMAGES.ctaRight,
    ],
    deliverables: [
      'Studio or on-location sessions',
      'Direction & wardrobe guidance',
      'Retouched final selects',
      'Personal & commercial usage licensing',
    ],
    process: [
      { step: '01', title: 'Concept call', body: 'We define mood, wardrobe and the story the portrait needs to tell.' },
      { step: '02', title: 'The session', body: 'A paced shoot with deliberate light and gentle direction to find the real frame.' },
      { step: '03', title: 'Select & retouch', body: 'You choose from a proof gallery; final selects are retouched and delivered in high resolution.' },
    ],
  },
  {
    slug: 'fashion',
    src: 'https://horizons-cdn.hostinger.com/1486e015-52d5-41a2-8639-d580c11ff37c/59b59e81c6c324258c7e9cc452804b2e.jpg',
    exhibit: 'EXH. 03',
    title: 'Fashion Photography',
    descriptor: 'High-conversion imagery with a contemporary edge',
    tag: 'Fashion',
    tagline: 'Editorial imagery with a contemporary edge.',
    overview: [
      'High-conversion fashion imagery with a contemporary edge. OB Production collaborates with designers, labels and stylists to build lookbooks, campaign sets and editorial spreads that define a modern visual language.',
      'From rooftop dawn shoots to controlled studio sets, every fashion frame is composed for the page it will live on — print, web or social — with a consistent grade that carries across the season.',
    ],
    gallery: [
      'https://horizons-cdn.hostinger.com/1486e015-52d5-41a2-8639-d580c11ff37c/59b59e81c6c324258c7e9cc452804b2e.jpg',
      'https://images.hostinger.com/7538c911-f29a-40d9-a38b-c474d1619a69.png',
      IMAGES.heroRight,
      IMAGES.ctaLeft,
    ],
    deliverables: [
      'Lookbook & campaign sets',
      'Editorial spread frames',
      'Consistent season grading',
      'Print, web and social crops',
    ],
    process: [
      { step: '01', title: 'Mood & storyboard', body: 'We align on references, casting, styling and the locations that carry the season.' },
      { step: '02', title: 'The shoot', body: 'A directed day on set or location, building frames for every page of the lookbook.' },
      { step: '03', title: 'Grade & layout', body: 'A unified grade across the set, delivered in every crop the campaign needs.' },
    ],
  },
  {
    slug: 'Corporate',
    src: 'https://iili.io/n7MkZ7e.jpg',
    exhibit: 'EXH. 04',
    title: 'Corporate Photography',
    descriptor: 'Polished precision for commercial studios',
    tag: 'Corporate',
    tagline: 'Polished precision for commercial studios.',
    overview: [
      'Polished precision for commercial studios. Catalogue-ready, brand-ready imagery for e-commerce listings, ad creative and commercial campaigns — shot to spec, on brief, and delivered fast enough to keep pace with a retail calendar.',
      'Every commercial set is built for consistency: matched lighting, matched backgrounds and a retouch standard that lets hundreds of SKUs sit side by side without a seam showing.',
    ],
    gallery: [
      'https://iili.io/n7MkZ7e.jpgttps://iili.io/n7GR2mx.jpg',
      IMAGES.product,
      IMAGES.food,
      IMAGES.studioPortrait,
    ],
    deliverables: [
      'Catalogue & listing frames',
      'Ad creative & campaign sets',
      'Consistent multi-SKU lighting',
      'Fast retail-calendar turnaround',
    ],
    process: [
      { step: '01', title: 'Spec & sample', body: 'We lock backgrounds, lighting and crop specs against a sample before the full run.' },
      { step: '02', title: 'Batch shoot', body: 'A controlled set built for consistency across every SKU in the catalogue.' },
      { step: '03', title: 'Retouch & export', body: 'Clean retouch and export in every crop the platform requires, delivered in batches.' },
    ],
  },
  {
    slug: 'food',
    src: IMAGES.food,
    exhibit: 'EXH. 05',
    title: 'Food Photography',
    descriptor: 'Catalogue-ready · Brand-ready content',
    tag: 'Food',
    tagline: 'Catalogue-ready, brand-ready food content.',
    overview: [
      'Catalogue-ready, brand-ready food content. OB Production works with restaurants, cloud kitchens and FMCG brands to make every dish look as good as it tastes — from menu cards and social reels to packaging and press.',
      'Food is styled and shot with an understanding of how it will be consumed: steam caught at the right second, texture lit for appetite appeal, and crops built for the square, the story and the printed menu.',
    ],
    gallery: [
      IMAGES.food,
      'https://images.hostinger.com/ea59e1f0-113d-4615-89c4-d4c993b05cf9.png',
      IMAGES.product,
      IMAGES.heroLeft,
    ],
    deliverables: [
      'Menu & social food frames',
      'Packaging & press shots',
      'Styled & lit for appetite appeal',
      'Square, story and print crops',
    ],
    process: [
      { step: '01', title: 'Menu & mood', body: 'We review the menu, brand voice and the platforms the content will live on.' },
      { step: '02', title: 'Styled shoot', body: 'Dishes styled and shot fresh, with light built for texture and appetite appeal.' },
      { step: '03', title: 'Edit & deliver', body: 'Colour-graded frames delivered in every crop the menu, feed and press need.' },
    ],
  },
  {
    slug: 'product',
    src: IMAGES.product,
    exhibit: 'EXH. 06',
    title: 'Product Photography',
    descriptor: 'Minimal · Modern · Premium',
    tag: 'Product',
    tagline: 'Minimal, modern, premium product frames.',
    overview: [
      'Minimal, modern, premium. Product photography built for D2C brands, marketplaces and luxury labels — clean backgrounds, considered light and a retouch finish that reads as premium at any size.',
      'Each product is shot with a lighting setup tuned to its material — matte, gloss, metal or glass — so the frame sells the object, not the studio trick behind it.',
    ],
    gallery: [
      IMAGES.product,
      'https://images.hostinger.com/ea59e1f0-113d-4615-89c4-d4c993b05cf9.png',
      IMAGES.food,
      IMAGES.studioPortrait,
    ],
    deliverables: [
      'Clean studio product frames',
      'Material-aware lighting',
      'Premium retouch finish',
      'Marketplace & brand crops',
    ],
    process: [
      { step: '01', title: 'Brief & surface', body: 'We define the surface, props and lighting approach against the product material.' },
      { step: '02', title: 'The shoot', body: 'Material-aware lighting tuned so the frame sells the object, not the trick.' },
      { step: '03', title: 'Retouch & export', body: 'A premium retouch and export in every crop the marketplace and brand need.' },
    ],
  },
];

export const SERVICES = [
  {
    number: '01',
    title: 'Events & Live Coverage',
    description:
      'From the electric energy of live events to candid, in-the-moment frames that capture the atmosphere as it unfolds.',
    src: 'https://images.hostinger.com/98f1fb85-3be6-4419-a4c3-805788d4c44c.png',
  },
  {
    number: '02',
    title: 'Portraits & Fashion',
    description:
      'Striking portraits and high-conversion fashion imagery that elevates every subject and defines contemporary visual language.',
    src: 'https://images.hostinger.com/7538c911-f29a-40d9-a38b-c474d1619a69.png',
  },
  {
    number: '03',
    title: 'Food, Product & E-Commerce',
    description:
      'Catalogue-ready, brand-ready and commercial-grade imagery with the polished precision of a commercial studio.',
    src: IMAGES.food,
  },
];

export const NAV_LINKS = [
  { label: 'Home', href: '/#home' },
  { label: 'Profile', href: '/#studio' },
  { label: 'Portfolio', href: '/#portfolio' },
  { label: 'Connect', href: '/#enquiry' },
];

export const CONTACT = {
  email: 'hello@reallygreatsite.com',
  phone: '123-456-7890',
  address: 'Mumbai, India',
  hours: 'By appointment — worldwide',
};

export const SOCIALS = [
  { label: 'Instagram', href: 'https://instagram.com' },
  { label: 'Facebook', href: 'https://facebook.com' },
  { label: 'LinkedIn', href: 'https://linkedin.com' },
];
