/// <reference path="../pb_data/types.d.ts" />
migrate(
  (app) => {
    const collection = app.findCollectionByNameOrId('enquiries');
    const field = collection.fields.getByName('sessionType');
    field.values = [
      'event',
      'portrait',
      'fashion',
      'ecommerce',
      'food',
      'product',
      'other',
    ];
    app.save(collection);
  },
  (app) => {
    const collection = app.findCollectionByNameOrId('enquiries');
    const field = collection.fields.getByName('sessionType');
    field.values = ['portrait', 'wedding', 'editorial', 'other'];
    app.save(collection);
  },
);
